cl6=140.112.90.200:18678

wget $cl6/loss_parent_sampler_higher_ratio.pth || gdown --id 1Lg8xm4b79F0DwKY4n8FAmHuSHUa9KJ5I
wget $cl6/loss_parent_sampler_longer.pth || gdown --id 1_ElloUGTiNcye97FZY5pHv8-MhpXhCUf
wget $cl6/loss_parent_sampler_meow.pth || gdown --id 10w13IPMGoINAD43WyYZO7hb6QX5rrtQ5
wget $cl6/loss_parent_sampler_ratio_8.0.pth || gdown --id 1Bm6tRMT1_0m3W4hzpt0RC_Pm4HpEXfqf
